class Ciphertext1(object):
    def __init__(self):
        self.T1 = None
        self.T2 = None
        self.T3 = None