class CipherPub(object):
    def __init__(self,T1 = None, T2 = None, PUB = None, exponent=0):
        self.T1 = T1
        self.T2 = T2
        self.PUB = PUB
